from django.db import models

# Create your models here.
class Project(models.Model):
    name=models.CharField(max_length=500)
    date=models.DateField(auto_now_add=True)
    proposal_send_is_done=models.BooleanField(default=False)

    pre_requirements=models.TextField()
    pre_requirements_is_done=models.BooleanField(default=False)
    template_selection_is_done=models.BooleanField(default=False)
    graphic_request_is_sent=models.BooleanField(default=False)
    graphic_is_done=models.BooleanField(default=False)
    logo_is_done=models.BooleanField(default=False)
    


    content_request_is_sent=models.BooleanField(default=False)
    content_is_done=models.BooleanField(default=False)
    frontend_is_done=models.BooleanField(default=False)
    domain_buy=models.BooleanField(default=False)
    backend=models.BooleanField(default=False)
    final_deploy=models.BooleanField(default=False)
    def __str__(self):
        return self.name