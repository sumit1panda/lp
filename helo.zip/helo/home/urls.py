from django.urls import path
from home import views
from home.views import *

urlpatterns = [
    path('',index.as_view()),
    path('project/<int:pk>',detail.as_view(),name='detail_view'),
]