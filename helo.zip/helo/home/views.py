from django.shortcuts import render
from home.models import *
from django.views.generic import ListView, DetailView

# Create your views here.d
class index(ListView):
    model=Project
    template_name="template.html"
    ordering=['-id']

class detail(DetailView):
    model=Project
    template_name="detail.html"
    
